# Reunión #0: Lluvia de ideas sobre nuestro proyecto

El día 3 de septiembre del 2025 nuestro equipo tuvo la primera reunión, una provisional, para empezar a decidir la idea a tomar para nuestro proyecto

# Ideas

Estas son las ideas propuestas grupalmente:

-Comanda de Restaurantes: Un proyecto a menor escala sobre un sistema de comanda para restaurantes.

-Roadmap Curricular: Un proyecto web donde se podrá organizar y elegir tus materias de tu malla curricular correspondiente a tu carrera 

-*Battleship: Una adaptación a videojuego basado en el juego de mesa “Battleship” con el añadido de un elemento de comodines y características especiales.

-*Risk Virtual: Una adaptación a videojuego basado en el juego de mesa “Risk”

-Delivery Emprendedores CCEI: Un aplicación para conectar los emprendedores con los estudiantes compradores en el campus de Ingeniería y Ciencias Exactas

-GitNote: Plataforma sencilla y de menos complejidad de alojamientos de repositorios Git. Busca mostrar de manera mas grafica los branches y archivos.

-Flow Chart: Un debugger visual con una interfaz comoda 

*Creemos que estas ideas no serán del agrado del cliente

# Roles

Actualmente de los cinco integrantes se le ha asignado solo a dos un rol

Isaac: Manager

Chay: Secretario y Redactor de Minutas

Al resto del equipo se le asignara en la siguiente reunion que se centrara en la organizacion del proyecto

# Lenguaje de programación

Finalmente el ultimo punto que se hablo en la reunión fue sobre el lenguaje de programacion a utilizar en el proyecto, debido a la indecisión del proyecto mismo solo tomaremos en cuenta dos lenguajes (Java, C++) y dependiendo de la idea a tomar se elegirá el lenguaje que mas se adapte al proyecto

![20250901-123814.JPG](20250901-123814.jpg)

(Foto de la pizarra donde se anotaron las ideas para el proyecto)

Debido a la improvisación de esta reunión no se grabo ni audio ni video pero las siguientes reuniones tendrán estas características para documentar con mayor precisión, al igual que se creara una bitácora escrita con los puntos relevantes de la reunión (como la que esta leyendo)